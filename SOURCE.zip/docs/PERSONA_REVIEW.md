# Week 12 synthetic persona screenshot review
Fresh-context subagent review of eight user-supplied screenshots, in order (19:52:37, 19:53:14, 19:54:00, 19:55:39, 19:56:42, 19:57:33, 19:58:16, 19:58:53). Fictional Mariana, 52, CDMX clinic navigator, paper/WhatsApp, limited time, slow digital reading, distrusts AI. Synthetic reactions, not a real interview or interactive agent test.

1 Initial: understands fictional-only notice; extraction wording unclear but willing to continue.
2 Review: Unknown creates hesitation about whether she must invent, investigate or leave it. Transport text clips.
3 Review and owner: reviewed Unknown conflicts with owner assigned below; route attestation is dense.
4 Route: source recorded but four actual route values not individually visible; prototype limitation.
5 Three steps: main confusion: original report says appointment not confirmed while current tracker says confirmed.
6 Closure blocked: understands attendance needed; evidence entry requires scrolling.
7 Closed: green evidence message helps; original report still appears inconsistent; no persistence encourages paper fallback.
8 Reopened: three steps returns without clear explanation of why.

Worst confusion: which panel reflects the current case? Fix: explicitly label original report and current tracker, clarify original appointment field, translate Unknown, explain Reviewed, use action verbs, and show an explicit reopened-case notice.

Post-fix verification: production compilation and unchanged domain regression tests. No post-fix browser screenshot or second screenshot persona pass yet. Guided user screenshots separately demonstrate unknown preservation, evidence gating, three-step open state, attendance-based closure and return to three steps. The reopened screenshot does not show the bottom close control, so it alone does not verify that control.
