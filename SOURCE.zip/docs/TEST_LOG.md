# Week 12 observed mechanical evidence
1 November 2026. Source inspection found the previous overdue calculation was referralCreated && currentStep < 4, independent of deadline. Simulated extraction always returned seeded facts, independent of report. Both defects were corrected with shared rules and targeted regression tests.

First targeted run: 1/3 tests passed, 2/3 failed. Calendar validation used local end-of-day followed by UTC formatting, changing the date under the executor timezone. Fix: validate the calendar date using explicit UTC noon; retain local end-of-day for the user's displayed deadline. Second run: all 3 tests passed. Cases cover future/past/completed overdue logic, omitted fact preservation, blank owner, impossible date and missing evidence.

No browser or persona screenshot test completed yet. No measured administrative-time benefit or clinical outcome. Deployment cycle still pending.

Post-deploy source review found a further misleading control: the route-verification checkbox could mark an all-Unknown route as verified without a source. It now requires a bounded source statement and explicit human attestation of all four route facts and 72-hour freshness. Changing that source clears verification and closure. This remains a simulated human attestation, not a live capacity or timestamp verification service.
First Week 12 deployment succeeded: appgdep_6ae7eb7421508191a5a7ee9fe0fcfcaf. Preview daemon timed out before healthy status; no browser screenshots or fresh-chat persona pass are claimed.
