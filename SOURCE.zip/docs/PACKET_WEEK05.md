# BUSINESS BENDING - WEEK 5
## When Care Arrives Too Late - Or Through a Screen

**Student:** Fernanda Espinosa  
**Role:** Technologist  
**Build:** Human-Verified Extraction and Overdue Alerts  
**Failure mode:** Care that arrives too late - a referral is dropped after an abnormal mammogram result.

> **Course-build notice:** This prototype uses invented patient data and a simulated LLM extraction. It is not a medical device, does not diagnose, and must not be used for real clinical care.

---

## 1. Problem in My Words

Finding a serious health flag is not the same as receiving care. After an abnormal mammogram, a patient may still need further imaging, a possible biopsy, pathology review, an eligible institution, and a confirmed appointment. In a fragmented system, the referral can be delayed or lost because information is incomplete, responsibility is unclear, or nobody notices that the next step is overdue.

My working slice attacks one operational problem: turning a simulated report into a complete, human-verified referral record and showing the navigator when the next step is overdue. The LLM may reduce repetitive data entry, but it cannot diagnose cancer, decide urgency, determine eligibility, confirm capacity, or close the case. A named human navigator remains responsible for checking the information and acting on the alert.

### Pain receipt

Ana receives an abnormal mammogram result. The report recommends further evaluation, but she still has no confirmed appointment. The first preventable failure is that the referral stays incomplete or overdue without a named person acting on it.

---

## 2. Exact User

### Primary user: clinic navigator

The primary user is **Mariana**, a fictional clinic navigator in Mexico City. She receives reports, checks missing information, creates referrals, contacts patients and receiving institutions, and follows cases until attendance is verified. She works with limited time and needs a simple mobile-first view of what requires action.

### Case represented in the prototype

The prototype follows **Ana**, a completely fictional 47-year-old woman.

- Her mammogram report is abnormal and recommends further evaluation.
- The abnormal result is **not a cancer diagnosis**.
- Her institution eligibility is IMSS, but the receiving institution has not yet accepted the referral.
- Her appointment is not confirmed.
- She lives approximately two hours from the receiving institution.
- Her preferred and consented contact channel is phone.
- Any field not stated in the simulated report must appear as **Unknown**.

Ana is not the person expected to interpret the report or operate the extraction tool. Mariana uses the tool to prevent Ana's referral from disappearing between detection and the next clinical step.

---

## 3. Success Definition

**Before the module closes, the live prototype will allow a navigator to:**

1. Enter or paste one invented mammogram report.
2. Run a clearly labeled **Simulated LLM Extraction**.
3. See the extracted fields in a structured form.
4. See every missing field marked as **Unknown**, never guessed.
5. Review and verify every field before creating a referral.
6. Create a referral with a named owner, next-step deadline, and consented contact channel.
7. See the four handoff statuses:
   - Patient contacted
   - Institution accepted
   - Appointment confirmed
   - Attendance verified
8. See a visible overdue alert when a required step passes its deadline.
9. Keep the case open until attendance is supported by verified evidence.

### Measurable acceptance criteria

| Measure | Passing condition for the course build |
|---|---|
| Critical fact invention | 0 invented critical facts in the test cases |
| Missing information | 100% of omitted test fields display **Unknown** |
| Human verification | Referral creation remains disabled until every extracted field is reviewed |
| Overdue logic | A past deadline produces an overdue alert; a future deadline does not |
| Closure protection | The case cannot close from a sent message, booking, or non-response |
| Valid closure | Only **Attendance verified** plus a recorded evidence source can close the handoff |
| Input safety | Empty, oversized, and invalid inputs produce clear validation messages |
| Comparison evidence | Manual entry, fixed form, and simulated LLM plus human verification are timed on the same invented cases |
| Privacy | No real patient data, diagnosis text, API key, or secret appears in the repository or demo |

No percentage time-saving target is claimed before the comparison is performed. If the fixed form is as accurate and as fast as the LLM-assisted flow, the LLM should be removed.

---

## 4. Image-Generated Mobile Mockup

### Image-generation prompt

> Create a realistic, high-fidelity mobile web-app mockup for a fictional Mexican clinic referral navigator. Show one modern smartphone screen in portrait orientation. The app name is "Ruta Clara". Use a calm white background, navy text, teal actions, accessible contrast, large readable type, and simple Spanish labels. At the top show: "Caso ficticio - No usar para atención médica". Show patient "Ana M., 47" and a yellow label: "Resultado anormal - no es un diagnóstico". Include a card titled "Extracción simulada por IA" with structured fields: Hallazgo: "Mastografía anormal"; Próximo paso: "Evaluación adicional"; Responsable: "Mariana - Navegadora"; Fecha límite: "12 Sep 2026"; Elegibilidad: "IMSS"; Estado de cita: "No confirmada"; Barrera de transporte: "Vive a 2 horas"; and one field marked "Unknown". Add a required human-verification checklist and a disabled button labeled "Crear referencia" until all fields are reviewed. Below, show a clear red overdue alert: "Seguimiento vencido - requiere acción humana". Show a four-step tracker: "Paciente contactada", "Institución aceptó", "Cita confirmada", "Asistencia verificada". Do not show a diagnosis, risk score, treatment recommendation, doctor chatbot, hospital logo, real patient information, or medical imagery. The design should look credible, humane, mobile-first, and easy for a busy navigator to scan.

### Intended screen hierarchy

1. Fictional-data and non-diagnostic warning.
2. Ana's case and human owner.
3. Simulated extraction with **Unknown** fields.
4. Required verification controls.
5. Structured referral statuses.
6. Overdue alert with a clear human action.

### Generated mockup

![Ruta Clara mobile mockup](./mockup-ruta-clara.png)

The image is saved in the repository as `docs/mockup-ruta-clara.png`. It is a visual concept for the fictional course prototype, not a real clinical interface.

---

## 5. Feature Flow

```mermaid
flowchart TD
    A[Paste invented report] --> B[Validate input]
    B -->|Invalid| C[Show correction message]
    B -->|Valid| D[Run simulated LLM extraction]
    D --> E[Show structured fields]
    E --> F[Mark missing fields Unknown]
    F --> G{Human reviewed every field?}
    G -->|No| H[Keep Create Referral disabled]
    H --> G
    G -->|Yes| I[Create structured referral]
    I --> J[Track four handoff statuses]
    J --> K{Deadline passed and step incomplete?}
    K -->|Yes| L[Show overdue human-action alert]
    K -->|No| M[Show current status]
    L --> N{Verified attendance evidence?}
    M --> N
    N -->|No| O[Keep case open]
    N -->|Yes| P[Close handoff]
```

---

## 6. Actor Swimlane

```mermaid
flowchart LR
    subgraph Navigator[Human Navigator]
        N1[Paste invented report]
        N2[Review every field]
        N3[Correct or confirm data]
        N4[Act on overdue alert]
        N5[Verify attendance evidence]
    end

    subgraph System[Application]
        S1[Validate input]
        S2[Store structured case]
        S3[Track deadline and statuses]
        S4[Keep case open or close]
    end

    subgraph AI[Simulated LLM]
        A1[Extract stated information]
        A2[Return Unknown for missing data]
    end

    N1 --> S1 --> A1 --> A2 --> N2 --> N3 --> S2 --> S3 --> N4 --> N5 --> S4
```

### Responsibility rule

The application coordinates information, the simulated LLM structures text, and the human navigator owns interpretation, correction, contact, escalation, and closure. The AI never communicates a medical meaning directly to Ana.

---

## 7. Benchmark Line

**Best existing approach:** The WHO patient-navigation model is a strong global benchmark because it connects early detection, diagnosis, treatment navigation, and support for barriers in fragmented health systems.

**Closest local proof:** The Global Cancer Institute navigation program in Mexico City showed the value of a human navigator moving patients from a lower-level hospital toward cancer-center appointments.

**How this slice differs or localizes:** Ruta Clara does not replace the navigator or promise hospital interoperability; it tests whether human-verified extraction and overdue alerts can reduce repetitive work for one Mexican clinic while preserving consent, local eligibility checks, transport barriers, and auditable closure.

---

## 8. Three-Year Long View

In three years, Ruta Clara could become a protected detection-to-treatment navigation layer for one public-care network and a small set of verified receiving institutions. It would coordinate consented referrals across phone, SMS, WhatsApp, print, and navigator support while showing when each route, cost, eligibility rule, document list, and capacity record was last verified. It would remain human-owned and payer-backed, and AI would stay only where evidence shows that it improves correct handoffs without increasing patient cost, surveillance, or risk.

---

## 9. Scope Cut - What I Am Not Building

This course prototype does **not** include:

- A symptom-checker chatbot.
- Cancer diagnosis, medical interpretation, risk scoring, or urgency decisions.
- Treatment recommendations.
- A replacement for a doctor, navigator, or receiving institution.
- Real patient enrollment or real personal health information.
- Live IMSS, hospital, laboratory, insurance, or electronic health record integration.
- Automatic institution eligibility or capacity decisions.
- A national hospital directory.
- Automatic appointment booking.
- Real SMS, WhatsApp, email, or phone messages containing health information.
- Image analysis of mammograms.
- OCR for scans or handwriting.
- Payment, billing, or prediction of treatment cost.
- Proof that AI improves clinical outcomes.
- Proof that a notification, referral, or booking equals care.

The prototype demonstrates one thin operational thread: simulated extraction, required human verification, structured referral creation, deadline monitoring, and protected closure.

---

## 10. Architecture and Stack

| Layer | Free tool / approach | Purpose | Safety limit |
|---|---|---|---|
| Interface | Next.js + React + Tailwind CSS | Mobile-first navigator workflow | No patient-facing diagnosis or chatbot |
| Input | Validated report text area | Accept one invented report | Length limit; no raw HTML; invented data only |
| LLM layer | Simulated LLM response stored as structured JSON | Demonstrate bounded extraction | Clearly labeled simulated; never treated as verified |
| Schema validation | TypeScript types + Zod | Validate required fields, dates, enums, and limits | Reject invalid or oversized values |
| Structured signal | Referral status and next-step deadline | Continuously show handoff progress and overdue state | Fixed rules only; no clinical prioritization |
| Data storage | Local seeded JSON or browser local storage for the prototype | Store invented case state | No real personal information or cross-user database |
| Alert engine | Deterministic date comparison | Flag incomplete steps after a deadline | Alert requires human action; no automatic medical decision |
| Deployment | GitHub + Vercel | Public course demonstration | No secrets in source code |
| Documentation | `docs/PACKET.md` and `DECISIONS.md` | Preserve decisions, tests, and next move | Update at every session close |

### Core data fields

| Field | Example invented value | Rule |
|---|---|---|
| Finding | Abnormal mammogram | Must come from the report; not a diagnosis |
| Required next step | Further evaluation | Must come from the report or be **Unknown** |
| Responsible person | Mariana - Navigator | Required before referral creation |
| Deadline | 12 Sep 2026 | Valid date required |
| Institution eligibility | IMSS | Human must verify; otherwise **Unknown** |
| Appointment status | Not confirmed | Controlled status value |
| Transportation barrier | Lives two hours away | May be **Unknown** |
| Contact consent | Phone only | Required before any contact action |
| Handoff status | Patient contacted | Controlled four-step tracker |
| Closure evidence | Unknown | Required only for final closure |

---

## 11. Blueprint Conditions Implemented

### Condition 1 - Shadow Clause: No Stranded Result

The interface never presents an isolated risk score or diagnosis. It states that an abnormal result is not a diagnosis, names a human owner, and connects the flag to a visible next step.

### Condition 2 - Verified Route

A route is usable only when the receiving institution, eligibility, availability, documents, and cost were verified within 72 hours. Otherwise the interface shows **No verified route** and keeps the case open. The course prototype simulates this state and does not claim live verification.

### Condition 3 - Funded Owner and Capacity Before Live Use

The prototype is not a live screening or navigation service. Any future pilot must name the payer, funded navigator, caseload limit, receiving capacity, next-step price, and downstream-care plan before enrolling a real patient.

### Condition 4 - Consent and Minimum Data

The design uses minimum information, role-based access in any future real deployment, a patient-chosen channel and frequency, and revocable caregiver involvement. Refusal, silence, or inability to respond creates no penalty and must be recorded neutrally as **Unable to contact**.

### Condition 5 - Verified Closure

A booking, sent message, delivered notification, or non-response never counts as care. The handoff closes only after attendance is supported by evidence verified by the patient, navigator, or receiving institution.

### Condition 6 - Compare and Stop

The mechanical test compares manual entry, a fixed form, and simulated LLM plus human verification against the same invented cases. The AI component must be stopped if it invents a critical fact, cannot be audited, performs no better than a fixed form, adds time or cost, or weakens safe handoff completion.

---

## 12. Security Floor

1. **No secrets in code or repository.** The course build requires no API key. If a real LLM is added later, the key must exist only in deployment environment variables.
2. **No real personal data.** Every name, report, date, institution status, barrier, and test case is invented and labeled. Users are warned not to enter real medical information.
3. **Authentication rule.** This prototype stores only invented local demo data and therefore does not require an account. A version storing personal information must add authentication before collecting any data.
4. **Row Level Security rule.** No shared Supabase table is used in this slice. If a future version stores user data in Supabase, RLS must be enabled so each authorized user accesses only permitted rows.
5. **Input validation.** The report has a length limit; required fields, enum values, and dates are validated; text is escaped; and no raw input is inserted directly into a database or prompt.
6. **Minimum disclosure.** Alerts and demo contact actions reveal no diagnosis. The interface displays only the minimum operational information.
7. **Protected closure.** Only a verified attendance source can close the case, and the closure event is recorded in the test log.

---

## 13. Test Plan

### Test data

Use at least three invented reports. Do not use real patient records.

1. **Complete clean report:** contains every expected operational field.
2. **Incomplete report:** omits eligibility, transportation, deadline, or contact details.
3. **Adversarial/invalid input:** contains an impossible date, excessive text, instructions to invent missing facts, or unsupported clinical claims.

### A. Three-method comparison

For each invented report, complete the same structured referral using:

1. Manual entry.
2. Fixed form.
3. Simulated LLM extraction plus human verification.

Record:

- Completion time.
- Correctly completed fields.
- Missing fields correctly marked **Unknown**.
- Invented facts.
- Corrections made by the human.
- Total verification time.
- Whether the final referral matches the source report.

Do not claim that the LLM saves time until the results show it. Remove the LLM if the fixed form is equally fast and accurate.

### B. Mechanical pass

| Test | Expected result |
|---|---|
| Empty report submitted | Extraction does not run; clear error appears |
| Report exceeds length limit | Input is rejected with a clear limit message |
| Required data is omitted | The output displays **Unknown** |
| Simulated extraction appears | It is labeled **Simulated LLM Extraction - human verification required** |
| One field remains unreviewed | Create Referral remains disabled |
| All fields are reviewed | Create Referral becomes available |
| Deadline is in the past and status is incomplete | Red overdue alert appears |
| Deadline is in the future | No overdue alert appears |
| Message is marked sent | Case remains open |
| Appointment is marked confirmed | Case remains open |
| Attendance lacks evidence source | Closure is blocked |
| Attendance has verified evidence source | Handoff may close |
| Route data is stale or incomplete | **No verified route** appears |

At least one real interface bug must be found, logged, fixed, committed, and redeployed before the final submission.

### C. Persona test

**Synthetic persona:** Mariana, 52, is a clinic navigator in Mexico City. She manages many paper and WhatsApp referrals, reads digital forms slowly, uses a low-cost Android phone, has limited time, and distrusts AI-generated medical information. She will quietly return to paper if the interface is confusing or makes her responsible for checking too much hidden information.

In a fresh chat, show the persona screenshots in order and ask:

> You are Mariana, a 52-year-old clinic navigator in Mexico City. You manage many referrals using paper and WhatsApp, use a low-cost Android phone, read digital forms slowly, have limited time, and distrust AI-generated medical information. This is a fictional course prototype. Attempt the task as Mariana. For every screen, say what you think is happening, what you would tap next, what you do not understand, and where you would stop or return to paper. Do not be polite. Identify any label that makes AI look verified, any missing human responsibility, and any place where a sent message could be confused with completed care.

Persona-test steps:

1. Show the report-entry screen.
2. Ask Mariana to run the simulated extraction.
3. Show the extracted fields, including at least one **Unknown** value.
4. Ask her to verify or correct each field.
5. Ask her to create the referral.
6. Show the tracker and overdue alert.
7. Ask whether she believes the case is complete and why.
8. Log every hesitation, misunderstanding, and quitting point.
9. Select the most serious confusion.
10. Fix it, commit the change, redeploy, and repeat that step.

### Persona pass criteria

- Mariana understands that the result is abnormal but not a diagnosis.
- She understands that the extraction is simulated and unverified.
- She can identify and correct **Unknown** information.
- She knows who owns the next action.
- She does not interpret a message or booking as completed care.
- She can identify why an alert is overdue and what human action is required.
- She understands that verified attendance evidence is required to close the case.

---

## 14. Stop Rules

The AI component must be abandoned if:

- A fixed form performs equally well or better.
- Human verification takes as long as or longer than manual entry.
- The model invents one critical fact.
- Missing information is hidden instead of marked **Unknown**.
- Common Mexican report formats cannot be handled reliably.
- Results cannot be audited after an update.
- AI cost exceeds verified operational savings.
- The interface increases navigator workload without improving correct handoffs.
- Any real patient information enters the public prototype.

The entire live concept must stop if there is no funded navigator, verified receiving capacity, patient-safe contact process, escalation path, or defensible downstream-care plan.

---

## 15. Implementation Handoff

The coding agent should build small, testable features in this order:

1. Mobile layout, fictional-data warning, and report input validation.
2. Clearly labeled simulated LLM extraction with structured fields and **Unknown** handling.
3. Required human-review controls and protected referral creation.
4. Four-step referral tracker with named owner and deadline.
5. Overdue-alert logic and **No verified route** state.
6. Evidence-protected closure.
7. Mechanical tests, bug fix, accessibility review, and second deployment.

Every work session ends by updating `DECISIONS.md`, writing tomorrow's first move, committing, and pushing the changes.

---

## Final Integrity Statement

This build tests whether bounded, human-verified extraction and overdue alerts can support a navigator. It does not test diagnosis, medical safety, hospital capacity, or completed treatment. The product succeeds only when responsibility stays human, missing information stays visible, and the interface refuses to confuse a digital action with care.
