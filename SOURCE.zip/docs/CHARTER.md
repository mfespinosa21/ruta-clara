# RUTA CLARA — Product Charter
Fernanda Espinosa · Week 12 · ADVERSARY · 1 November 2026

## Purpose and exact user
Make the next incomplete referral step visible, owned and verifiable. The primary operator is a clinic navigator in Mexico City; the beneficiary is a person left repeatedly calling to understand an unfinished referral. Mariana and Ana are fictional demo personas. My grandmother's repeated calls motivate the question but do not establish its cause or a validated market.

## Core promise
A navigator can inspect a fictional referral, identify its next incomplete handoff, attach a human owner and deadline, and record evidence before advancing. Contacted, institution accepted, appointment confirmed and attendance verified are separate states. A sent message or booking cannot close a case.

## Principles
Unknown stays unknown. Human review precedes action. Editing a reviewed fact invalidates its review. Every completed step needs an evidence source. Corrections reopen the affected step and dependent steps. Overdue means a deadline passed, not that the patient failed. Do not claim that software creates receiving capacity.

## Non-goals
No diagnosis, triage, treatment, real patient enrollment, live messages, booking, payments, institution integrations, AI benefit claim or additional product feature. The 20-minute versus 2-minute comparison is a model, not measured savings.

## Three-year direction
Ruta Clara could support one funded navigation team and a small verified receiving network. It would preserve consent, current route information and a visible correction history across referrals. Expansion depends on observed usefulness, funded ownership and receiving capacity rather than simulated completion.

## Inherited conditions and missing authority
Preserve Week 5's no-stranded-result safeguard, human ownership, unknowns, verified route freshness within 72 hours, consent and evidence-based closure. These are inherited from the existing Week 5 packet, not a verified Week 12 Blueprint. The Week 12 Crystal Ball Brief, advisory conditions and exact shadow clause have not been supplied; compliance remains unverified.

## Live-use gate
Do not enroll anyone until a payer, funded navigator, backup, caseload limit, receiving capacity, correction route and downstream plan are verified. Personal-data use requires Google sign-in, Supabase Auth, RLS isolation, input validation and appropriate access review before collection.

## Venture independence gate
Required but incomplete: venture email and GitHub identity, transferred source, Vercel and Supabase projects under that identity, and purchased connected real domain. Current Sites publication is a prototype environment and does not satisfy this milestone.
