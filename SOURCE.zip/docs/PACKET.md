# RUTA CLARA — Week 12 Build Packet
Fernanda Espinosa · ADVERSARY · 1 November 2026

## Authority and packet-before-code
Read CHARTER.md first. This packet precedes Week 12 implementation; the prior Week 5 packet is preserved as PACKET_WEEK05.md. Method step 3 becomes the core: find the next incomplete handoff, give it an owner and deadline, and require verified evidence before completion. Week 12 Crystal Ball and Blueprint conditions are unavailable; their compliance is unverified.

## Problem, user and success
A clinic navigator needs to finish a referral but scattered status information hides who must act next. Mariana, a fictional CDMX navigator, operates this prototype; Ana is a fictional beneficiary. Before the module closes, the prototype must show the next incomplete step, validate an owner/deadline, flag actual overdue status, require evidence to advance, and protect closure until attendance is verified. All examples and AI outputs remain explicitly simulated.

## Mockup
![Image-generated conceptual dashboard](mockup-week12.png)

Generated before implementation. This is a concept, not a screenshot: incidental dates, cardiology text and navigation tabs are illustrative and are not implemented scope. The working prototype retains the original referral scenario.

## Feature flow
```mermaid
flowchart TD
 A[Open fictional case] --> B[Review stated facts and unknowns]
 B --> C{Owner and deadline valid?}
 C -->|No| D[Show correction]
 D --> B
 C -->|Yes| E[Show next incomplete handoff]
 E --> F{Deadline passed?}
 F -->|Yes| G[Show overdue action]
 F -->|No| H[Show pending action]
 G --> I[Human records evidence]
 H --> I
 I --> J{Evidence valid?}
 J -->|No| E
 J -->|Yes| K[Advance one step]
 K --> L{Attendance verified?}
 L -->|No| E
 L -->|Yes| M[Allow protected closure]
 K --> N[Correction invalidates dependent steps]
 N --> E
```

## Actor swimlane
```mermaid
flowchart TD
 subgraph Navigator
 N1[Review facts]
 N2[Assign owner and deadline]
 N3[Record evidence or correction]
 end
 subgraph System
 S1[Validate and preserve unknowns]
 S2[Display next step and overdue state]
 S3[Advance or reopen dependent steps]
 end
 subgraph Receiving_institution
 R1[Provide acceptance or attendance evidence outside demo]
 end
 N1 --> S1 --> N2 --> S2 --> N3 --> S3
 R1 -. human verification .-> N3
 S3 --> S2
```

## Benchmark line
My selected global product benchmark is Unite Us Closed-Loop Referral System, whose official product page describes referral and service-outcome tracking beyond sending a referral; this is a selected benchmark, not a proven world ranking. Ruta Clara localizes a narrower Spanish-language, human-owned referral workflow for one Mexican clinic, with visible unknowns, deadlines and evidence-protected attendance closure.
Source: https://uniteus.com/products/closed-loop-referral-system/ (reviewed 1 November 2026). No claim of comparable integrations, certification or results.

## Long view
In three years this slice could become a protected referral layer for one funded navigation network. Each route would show when eligibility, capacity, documents and cost were last verified. Scaling would require measured benefit and human capacity, with AI retained only if it beats a fixed form at equal accuracy.

## Scope cut
Only the inherited core. No real patients, clinical decisions, live messages, booking, payments, new hospital directory or new venture idea. No claim that simulated extraction is a functioning LLM or that the modeled 10:1 ratio has been observed.

## Architecture and stack
| Layer | Current prototype | Required milestone / gap |
|---|---|---|
| UI | Existing React / Next-compatible Vinext / Tailwind | Preserve core and accessible Spanish UI |
| Rules | Deterministic TypeScript/JavaScript state machine | Test transitions, validation and actual deadline comparison |
| Data | Fictional in-memory session only | No personal data collection or shared database |
| AI | Labeled deterministic simulation | No real LLM or benefit claim |
| Hosting | Existing Sites source and hosting | Vercel under venture identity remains pending |
| Auth / DB | Not used for fictional session | Supabase + Google Auth + RLS required before personal data |
| Source | Sites Git repository | Venture GitHub identity and transfer pending |
| Domain | Existing chatgpt.site subdomain | Purchased real domain not connected |

## Security floor
No keys needed or committed. No real patient names, reports or other personal data in seeds. Limit every text/date field, validate required values and escape rendering. No user database, external messages or persistent clinical data. This fictional prototype does not demonstrate Supabase Auth or RLS; do not report those checks as implemented.

## Tests and evidence policy
Mechanical: missing/whitespace owner; empty or invalid deadline; past versus future deadline; unreviewed and changed facts; missing evidence; step order; premature closure; correction reopens affected and later steps; restart clears state. Preserve at least one observed failure with before/after evidence, fix and redeploy; do not manufacture a bug. Check small-screen layout and keyboard use when preview is available.
Persona: fresh-context synthetic navigator Mariana, 52, paper/WhatsApp workflow, limited time, distrusts AI. Walk ordered actual screenshots, record hesitations and fix the worst. A text review is not the required fresh-chat screenshot test; label any missing procedure honestly. No interview, field test or real-user outcome claim.
Comparison: time manual records, fixed form and assisted flow on matched fictional cases; count setup, correction and maintenance. No measured result yet.

## Commit and deployment plan
1 Charter and packet before code. 2 Core next-action rules. 3 UI integration. 4 Mechanical evidence and first deployment. 5 Observed fix, decision log and second deployment. Keep actual commits and deployment IDs, not invented history.

## Pending acceptance gates
Real domain; venture identity; GitHub/Vercel/Supabase migration; missing Blueprint/shadow-clause verification; two completed deployments; documented mechanical and fresh-chat persona passes; full development transcript; user-recorded 3:30 video. A working subdomain does not meet the course URL-of-record rule.
