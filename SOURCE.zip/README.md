# Ruta Clara

Run npm install then npm run dev.
Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY in deployment environment; no secret/service-role key is used.
Current URL: https://ruta-clara-pied.vercel.app
Email-link authentication, fictional demo only. Google and real domain pending.
