import {test} from 'node:test';
import assert from 'node:assert/strict';
import {isOverdue,extract,canAdvance,validDate} from '../lib/handoff.mjs';
test('future deadline remains pending, past deadline overdue, completed case not overdue',()=>{const now=new Date('2026-11-02T12:00:00');assert.equal(isOverdue('2026-11-03',0,now),false);assert.equal(isOverdue('2026-11-01',0,now),true);assert.equal(isOverdue('2026-11-01',4,now),false);});
test('missing report values stay unknown instead of seeded facts',()=>{const result=extract('Hallazgo: Ejemplo ficticio');assert.equal(result[0].value,'Ejemplo ficticio');assert.equal(result[2].value,'Unknown');assert.equal(result[4].value,'Unknown');});
test('owner, valid calendar date and evidence required',()=>{assert.equal(canAdvance('  ','2026-11-02','Fuente ficticia'),false);assert.equal(validDate('2026-02-30'),false);assert.equal(canAdvance('Mariana','2026-11-02',''),false);assert.equal(canAdvance('Mariana','2026-11-02','Llamada ficticia verificada'),true);});
