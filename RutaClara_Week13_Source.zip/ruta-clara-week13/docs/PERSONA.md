# Ruta Clara | Week 13 persona-test log
Fernanda Espinosa | 5 November 2026

## What was actually done
A separate fresh-context synthetic persona agent reviewed three ordered screenshots of the live app. It received Mariana's persona and screenshot paths, without app source. The operator performed browser actions and the synthetic persona narrated imagined attempts. This is not a real-user interview, autonomous user session, test of clinical outcomes or five-user validation. One full-page screenshot attempt timed out; viewport captures were used instead.

## Synthetic user
Mariana, 52, fictional referral navigator in CDMX. Uses paper and WhatsApp, reads slowly under time pressure, distrusts AI and gives up when a screen seems to ask her to confirm something she does not know. She must record contact evidence, understand the next institutional acceptance step and distinguish it from availability or attendance.

## Screen 1 - contact evidence before the fix
Actual screenshot: persona-evidence.png. Contact source and fictional recorder entered; human attestation checked; route still pending.
Simulated quote: "Aquí dice verificación ficticia confirmada, pero abajo la ruta sigue pendiente. Si registro, ¿ya estoy diciendo que la institución sí la recibe?"
Simulated quote: "Yo pondría que le mandé WhatsApp a la señora, pero aquí en Fuente ¿quieren su teléfono, su nombre o copiar lo que contestó?"
Hesitation: the confirmation label sounds global. She may think she certified institutional capacity while only confirming contact. Privacy guidance must also explain what a source field should contain.

## Screen 2 - next institutional step
Actual screenshot: persona-next.png, after the operator registered fictional contact. Progress 1/4; institutional acceptance is next; route remains pending.
Simulated quote: "Ya aparece Paciente contactada, eso sí lo entiendo. Pero otra vez dice reportado, aún sin verificar. ¿Lo que acabo de guardar no quedó verificado?"
Simulated quote: "Ese número largo después de DEMO no lo puedo revisar así de rápido; yo buscaría una fecha y una hora normales."
Hesitation: a new pending label appears without naming its scope; she may infer that the previous contact evidence was lost. Technical timestamp format raises reading effort.

## Worst confusion and shipped fix
Priority: confirmation scope, because it risks false reassurance or abandonment. Commit 1878c55 changes status text to name the exact current step, says previous steps keep their evidence, and distinguishes verification of a contact from availability or care received. It adds a short input checklist and tells the navigator when the route review below is also needed. Source guidance excludes phone numbers and personal data. Evidence history displays a human-readable Mexico City timestamp. Deployment 2: dpl_9ouVi9Hcwcr1hd2vDkRogixRCii2, READY.

## Screen 3 - post-fix retest
Actual screenshot: persona-fixed.png, same contact task on second publication.
Simulated quote: "Ahora sí dice este paso y Paciente contactada. Entiendo que confirmar el contacto no asegura que haya lugar ni que ya la atendieron. Todavía tengo que revisar la institución."
Remaining hesitation: "Es mucho texto para leer con prisa. Y esta captura volvió a contacto; quisiera ver lo mismo cuando toque que la institución acepte."
Conclusion: the simulated reader understood the revised contact wording. The retest does not establish human understanding, institutional-step usability, adoption or safety. Further real-user observation may require shorter progressive instructions.

## Additional mechanical observation
While testing attendance with appointment-category evidence, advancement and closure stayed disabled as intended, but checked attestation still made status text say confirmed. Commit 60c7a00 ties that label to the same evidenceReady predicate. Third publication follows this fix; this is a mechanical display finding, not a human-user pain ranking.

## Five-human requirement remains pending
Recruit five actual referral navigators, >=3 strangers, no classmates, no coaching and fictional cases only. Record role, task, struggle and exact consented quotes with U1-U5, then rank three pains by harm/blockage/effort. Ship and retest the observed #1 fix and seek an observable return action. This synthetic log cannot substitute for any of those sessions.
