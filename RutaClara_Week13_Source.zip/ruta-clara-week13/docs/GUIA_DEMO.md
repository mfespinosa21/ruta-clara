# Week 13 | Guia de cierre y video
Fernanda Espinosa | Ruta Clara

## Estado para entregar
GitHub ya contiene el código y los documentos de Week 13; el bloqueo de escritura está resuelto. La app usa https://ruta-clara-pied.vercel.app/ y el repositorio es https://github.com/mfespinosa21/ruta-clara. La usuaria eligió conservar la URL gratuita; no cumple el requisito de dominio propio y no tenemos excepción del profesor. Google sigue bloqueando la verificación de identidad; se conserva el acceso por correo y Google Sign-In sigue sin configurarse. No hace falta comprar nada para seguir usando el prototipo.

Faltan el video de la alumna, la exportación íntegra del chat y las cinco pruebas reales con sus resultados, corrección y segunda prueba. El suplemento de cinco perfiles está etiquetado como ejercicio ficticio y no acredita esas entrevistas. El BUILDCHAT ampliado contiene el registro técnico y extractos disponibles; no es la exportación completa.

## Prueba con cinco personas
Busca personas que de verdad hagan seguimiento de referencias, por ejemplo personal de recepción o navegación clínica; no les pidas expedientes. Explica: "Estoy probando la pantalla, no tus capacidades. Todo el caso es inventado. Puedes parar cuando quieras. No necesito tu nombre ni datos de pacientes". Registra consentimiento sin identificadores innecesarios; si no acepta, no inicies la sesión.

Usa U1-U5; anota rol y si es desconocido. Da estas tareas sin enseñar dónde picar: identificar siguiente paso; asignar responsable/plazo; registrar contacto; confirmar aceptación; intentar cerrar con una cita; corregir una aceptación ya registrada. Pregunta "¿Qué harías ahora?" y observa. No sustituyas observación por "¿te gustó?". Alterna orden manual/app entre usuarios con casos equivalentes. Cuenta acceso, preparación, revisión, errores, correcciones y soporte, además del tiempo de tarea.

## Ficha para cada sesión - sin resultados precargados
Usuario U__: rol __; desconocido sí/no __; no compañero __; consentimiento __; orden manual/app __. Tarea __; resultado observado __; segundos manual __; segundos app __; preparación __; ayuda __; cierre incorrecto __; cita exacta __; dónde se detuvo __; siguiente acción voluntaria de retorno __. No llenes con estimaciones inventadas.

## Elegir y volver a probar
Anota tres dolores observados. Para cada uno registra daño (0-3), bloqueo (0-3) y esfuerzo total (0-3), con evidencia de sesión; usa la suma solo como ayuda y explica tu decisión. Corrige el #1, guarda versión anterior/nueva y despliegue. Vuelve con el usuario afectado para observar la misma tarea sin coaching. Solicita una acción observable de retorno: que use otra vez el caso ficticio por iniciativa o acuerdo concreto; una promesa no prueba adopción. No afirmes ahorro sin comparación de igual calidad.

## Video: 3 minutos + 30 segundos, cámara encendida
0:00-0:25 Abre https://ruta-clara-pied.vercel.app/ y muestra el aviso de datos ficticios. Aclara que es la URL gratuita actual; no la presentes como dominio propio.
Say: "This is Ruta Clara, a fictional referral-follow-up prototype for a Mexican clinic navigator. It shows the next incomplete step, its owner and deadline. All examples and AI outputs are simulated."

0:25-1:00 Ejecuta extracción simulada, revisa datos y crea referencia.
Say: "Reviewing the original report does not mean the referral is complete. Unknown information stays visible, and a human owns the next action."

1:00-1:45 Registra fuente y persona ficticias, categoría y revisión. Muestra que una cita no confirma asistencia.
Say: "Each step needs an attributed source and explicit fictional verification. A message or an appointment cannot be used as attendance evidence. These checks structure a claim; they cannot establish that a real event happened."

1:45-2:20 Muestra corrección y reapertura de dependencias; no uses datos reales.
Say: "Correcting an earlier step reopens that step and the later ones. The app does not leave a reassuring completed state after the evidence changes."

2:20-3:00 Abre el registro, marca una confusión y exporta JSON. Si muestras acceso, oculta correo/enlace de login y explica que funciona por email, no Google. Si cargas copia, explica que exige nueva verificación desde paso cero.
Say: "The diagnostic log records action type, step and elapsed time, without report text or names. It is a session-level diagnostic tool, not proof of clinical outcomes or completed user research."

3:00-3:30 Cambio de opinión, adapta a lo que realmente pasó.
Say: "I thought a clear verification label would be enough. In a synthetic screenshot walkthrough, the navigator interpreted a contact confirmation as confirmation of the whole route. I changed the label to name the exact step and explain what remains missing. The technical date test also found a real exception, which I fixed and redeployed. Real-user validation and the remaining infrastructure requirements are still pending."

No digas que entrevistaste a cinco personas hasta realizarlas. Después de las sesiones, sustituye el cierre por el aprendizaje observado, sin inventarlo.

## Dropbox
Live URL del dominio real; GitHub con código y commits; DEMO_FernandaEspinosa.mp4; PACKET_FernandaEspinosa.pdf; PERSONA_FernandaEspinosa.pdf; BUILDCHAT_FernandaEspinosa.pdf con conversación completa. Adjunta la guía solo si la piden. Los documentos actuales marcan los pendientes, no acreditan trabajo no realizado.
