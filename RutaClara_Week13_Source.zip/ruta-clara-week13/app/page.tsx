"use client";

import { useMemo, useState } from "react";
import EventLog, {recordEvent} from '@/components/EventLog';
// @ts-ignore tested shared rules
import {evidenceReady, provenance, routeFresh} from '../lib/audit.mjs';
import CloudSession from "@/components/CloudSession";
// @ts-ignore — shared tested JavaScript rules
import {extract, isOverdue, canAdvance, validDate, validText} from "../lib/handoff.mjs";
import { AlertTriangle, Check, Clock3, FileText, HeartHandshake, RotateCcw, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";

type Field = { label: string; value: string; reviewed: boolean };
const sampleReport = `REPORTE SIMULADO - DATOS COMPLETAMENTE FICTICIOS
Paciente: Ana M., 47 años
Hallazgo: Mastografía anormal
Siguiente paso: Evaluación adicional
Elegibilidad: IMSS
Estado de cita: No confirmada
Barrera de transporte: Vive a dos horas de la institución receptora
Canal de contacto: No indicado`;
const steps = ["Paciente contactada", "Institución aceptó", "Cita confirmada", "Asistencia verificada"];

export default function Home() {
  const [report, setReport] = useState(sampleReport);
  const [error, setError] = useState("");
  const [fields, setFields] = useState<Field[] | null>(null);
  const [referralCreated, setReferralCreated] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [routeVerified, setRouteVerified] = useState(false);
  const [routeEvidence, setRouteEvidence] = useState("");
  const [attendanceEvidence, setAttendanceEvidence] = useState(false);
  const [closed, setClosed] = useState(false);
  const [owner, setOwner] = useState("Mariana — navegadora ficticia");
  const [deadline, setDeadline] = useState("2026-11-04");
  const [evidence, setEvidence] = useState("");
  const [correctionNotice, setCorrectionNotice] = useState(false);
  const [recorder,setRecorder]=useState('');
  const [kind,setKind]=useState('contact');
  const [attested,setAttested]=useState(false);
  const [routeAt,setRouteAt]=useState('');
  const [history, setHistory] = useState<string[]>([]);
  const allReviewed = fields?.every((field) => field.reviewed) ?? false;
  const canClose = currentStep === 4 && attendanceEvidence && history.length === 4 && routeFresh(routeAt);
  const overdue = referralCreated && isOverdue(deadline, currentStep);
  const progress = useMemo(() => (currentStep / steps.length) * 100, [currentStep]);

  function runExtraction() {
    const clean = report.trim();
    if (!clean) return setError("Pega un reporte ficticio antes de ejecutar la extracción.");
    if (clean.length > 3000) return setError("El reporte debe tener 3,000 caracteres o menos.");
    setError(""); recordEvent("extract",0); setAttested(false); setRouteAt("");
    setFields(extract(clean));
    setHistory([]); setEvidence(""); setCorrectionNotice(false);
    setReferralCreated(false);
    setCurrentStep(0);
    setRouteVerified(false); setRouteEvidence("");
    setAttendanceEvidence(false);
    setClosed(false);
  }
  function resetDemo() {
    recordEvent("reset",0); setRouteAt(""); setAttested(false); setRecorder(""); setKind("contact");
    setHistory([]); setEvidence(""); setCorrectionNotice(false); setOwner("Mariana — navegadora ficticia"); setDeadline("2026-11-04");
    setReport(sampleReport); setFields(null); setReferralCreated(false); setCurrentStep(0);
    setRouteVerified(false); setRouteEvidence(""); setAttendanceEvidence(false); setClosed(false); setError("");
  }

  return (
    <main className="min-h-screen bg-[#f4f8f8] text-[#12233f]">
      <header className="border-b border-[#d7e4e5] bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-4 sm:px-8">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[#087f7a] text-white"><HeartHandshake aria-hidden="true" /></span>
            <div><p className="text-xl font-bold tracking-tight">Ruta Clara</p><p className="text-sm text-[#53657a]">Seguimiento con responsable humano</p></div>
          </div>
          <Button variant="outline" onClick={resetDemo}><RotateCcw aria-hidden="true" /> Reiniciar</Button>
        </div>
      </header>
      <div className="mx-auto max-w-6xl px-4 py-6 sm:px-8">
        <div className="mb-6 flex gap-3 rounded-2xl border border-[#bfd9d7] bg-[#eaf6f5] p-4 text-sm">
          <ShieldCheck className="mt-0.5 shrink-0 text-[#087f7a]" aria-hidden="true" />
          <div><strong>Prototipo académico ficticio - no usar para atención médica.</strong><p className="mt-1 text-[#4d6273]">Un resultado anormal no es un diagnóstico. Todos los datos y resultados de IA son simulados.</p></div>
        </div>
        <CloudSession value={{next_owner:owner,deadline,completed_steps:currentStep,evidence:history,closed,route_verified:routeVerified,route_evidence:routeEvidence}} canSave={referralCreated} onSignOut={resetDemo} onLoad={v=>{setOwner(v.next_owner);setDeadline(v.deadline);setCurrentStep(0);setHistory([]);setClosed(false);setRouteVerified(false);setRouteAt("");setRouteEvidence(v.route_evidence);setAttendanceEvidence(false);setReferralCreated(true);setFields(null);setEvidence("");setAttested(false);setKind('contact');setCorrectionNotice(true);recordEvent('load',0);}} /><section className="grid gap-6 lg:grid-cols-[1.02fr_.98fr]">
          <div className="space-y-6">
            <article className="surface">
              <div className="section-head"><span className="step-number">1</span><div><h1>Ingresa un reporte ficticio</h1><p>Mariana pega el reporte para revisarlo.</p></div></div>
              <label htmlFor="report" className="field-label">Texto del reporte simulado</label>
              <Textarea id="report" value={report} onChange={(e) => setReport(e.target.value)} className="mt-2 min-h-48 bg-white text-base" maxLength={3001} />
              <div className="mt-2 flex justify-between text-sm text-[#66778a]"><span>Nunca ingreses datos reales.</span><span>{report.length}/3000</span></div>
              {error && <p role="alert" aria-live="polite" className="mt-3 rounded-xl bg-red-50 p-3 text-sm font-medium text-red-700">{error}</p>}
              <div className="mt-4 flex flex-wrap gap-3"><Button onClick={runExtraction} className="bg-[#087f7a] hover:bg-[#066b67]"><FileText aria-hidden="true" /> Ejecutar extracción simulada</Button><Button variant="outline" onClick={() => setReport(sampleReport)}>Cargar ejemplo</Button><Button variant="ghost" onClick={() => setReport("")}>Limpiar</Button></div>
            </article>
            {fields && <article className="surface">
              <div className="section-head"><span className="step-number">2</span><div><h2>Revisa los datos del reporte original</h2><p>Extracción simulada. Estos datos son del reporte original; el seguimiento actual aparece a la derecha.</p></div></div>
              <div className="divide-y divide-[#e3ebec] rounded-2xl border border-[#dce7e8] bg-white px-4">
                {fields.map((field, index) => <div key={field.label} className="grid gap-3 py-4 sm:grid-cols-[1fr_1.2fr_auto] sm:items-center"><label htmlFor={`field-${index}`} className="text-sm font-semibold">{field.label === "Estado de cita" ? "Cita según reporte original" : field.label}</label><input id={`field-${index}`} value={field.value === "Unknown" ? "No indicado en el reporte" : field.value} onChange={(e) => setFields(fields.map((item, i) => i === index ? { ...item, value: e.target.value || "Unknown", reviewed: false } : item))} maxLength={300} disabled={referralCreated} className={field.value === "Unknown" ? "data-input unknown" : "data-input"} /><label className="flex items-center gap-2 text-sm font-medium"><Checkbox disabled={referralCreated} checked={field.reviewed} onCheckedChange={(checked) => setFields(fields.map((item, i) => i === index ? { ...item, reviewed: checked === true } : item))} /> Revisado</label></div>)}
              </div>
              <div className="mt-4 rounded-xl bg-[#fff6d8] p-3 text-sm text-[#725710]"><strong>Verificación humana obligatoria.</strong> “Revisado” significa que comparaste el dato con el reporte; no que completaste un dato faltante. Asigna el responsable y el plazo del seguimiento abajo. La navegadora es responsable de cada corrección y confirmación.</div>
              <div className="mt-4 space-y-3"><label className="block">Responsable del siguiente paso<input className="data-input mt-2 w-full" maxLength={100} value={owner} onChange={e=>setOwner(e.target.value)} /></label><label className="block">Fecha límite del siguiente paso<input className="data-input mt-2 w-full" type="date" value={deadline} onChange={e=>setDeadline(e.target.value)} /></label><p className="text-sm">Sin guardar una copia en tu cuenta, recargar borra el seguimiento. Usa solo información ficticia.</p></div>
              <Button disabled={!allReviewed || !validText(owner) || !validDate(deadline) || referralCreated} onClick={() => {setReferralCreated(true);recordEvent("create",0);}} className="mt-4 w-full bg-[#087f7a] hover:bg-[#066b67]">Crear referencia estructurada</Button>
            </article>}
          </div>
          <aside className="space-y-6"><article className="surface sticky-card">
            <div className="flex items-start justify-between gap-4"><div><p className="eyebrow">Caso ficticio</p><h2 className="mt-1 text-2xl font-bold">Ana M., 47</h2></div><span className="rounded-full bg-[#fff1b8] px-3 py-1 text-xs font-bold text-[#6e5100]">No es diagnóstico</span></div>
            {!referralCreated ? <div className="empty-state"><Clock3 aria-hidden="true" /><p>Crea una referencia verificada para comenzar el seguimiento.</p></div> : <>
              {overdue && <div role="alert" className="mt-5 flex gap-3 rounded-2xl border border-red-200 bg-red-50 p-4 text-red-800"><AlertTriangle className="shrink-0" aria-hidden="true" /><div><strong>Seguimiento vencido - requiere acción humana</strong><p className="mt-1 text-sm">{owner} debe verificar el siguiente paso antes de {deadline}. Ana no recibe una etiqueta de incumplimiento.</p></div></div>}
              {correctionNotice && <p role="status" className="mt-4 rounded-xl bg-amber-50 p-3 text-sm">Caso reabierto: se retiró la verificación afectada y la de los pasos posteriores. Al cargar una copia histórica, todos los pasos requieren nueva verificación; la copia guardada no se modifica hasta que guardes otra.</p>}<div className="mt-5 rounded-xl bg-[#eaf6f5] p-4"><strong>{currentStep < 4 ? "Próxima acción: " + ["Registrar contacto con la paciente", "Confirmar aceptación de la institución", "Confirmar la cita", "Verificar si la paciente asistió"][currentStep] : "Asistencia verificada: revisa el cierre"}</strong><p className="mt-2 text-sm">Responsable: {owner} · Fecha límite: {deadline}</p><p className="text-sm">{overdue ? "Vencido: requiere seguimiento humano" : currentStep < 4 ? "Paso pendiente; fecha límite aún no vencida" : "Los cuatro pasos están verificados"}</p></div>
              <div className="mt-5 flex items-center justify-between"><h3 className="font-bold">Seguimiento actual de la referencia</h3><span className="text-sm font-semibold">{currentStep} de 4</span></div>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-[#dfe9ea]"><div className="h-full bg-[#087f7a] transition-all" style={{ width: `${progress}%` }} /></div>
              <ol className="mt-4 space-y-3">{steps.map((step, index) => <li key={step} className="flex items-center gap-3"><span className={index < currentStep ? "status-dot done" : "status-dot"}>{index < currentStep ? <Check size={16} /> : index + 1}</span><span className={index < currentStep ? "font-semibold" : "text-[#718092]"}>{step}</span></li>)}</ol>
              {currentStep < 4 && <div className="mt-5"><label htmlFor="step-evidence" className="field-label">Fuente de evidencia del siguiente paso (ficticia)</label><input id="step-evidence" maxLength={120} className="data-input mt-2 w-full" value={evidence} onChange={e=>{setEvidence(e.target.value);setAttested(false);}} placeholder="Ej.: confirmación telefónica ficticia verificada"/><label className="mt-3 block text-sm">Persona que registra (ficticia)<input className="data-input mt-2 w-full" value={recorder} maxLength={60} onChange={e=>{setRecorder(e.target.value);setAttested(false);}} /></label><label className="mt-3 block text-sm">Tipo de evidencia<select className="data-input mt-2 w-full" value={kind} onChange={e=>{setKind(e.target.value);setAttested(false);}}><option value="contact">Contacto / mensaje</option><option value="acceptance">Aceptación institucional</option><option value="appointment">Cita confirmada</option><option value="attendance">Asistencia confirmada por receptor</option></select></label><p className="mt-2 text-sm">Una cita o mensaje no prueba asistencia. Estado de este paso ({steps[currentStep]}): {evidenceReady(evidence,recorder,kind,attested,currentStep) ? 'verificación ficticia confirmada SOLO para este paso' : 'pendiente de verificación para este paso'}. Los pasos anteriores conservan su evidencia; esto no confirma disponibilidad ni atención recibida.</p><label className="mt-3 flex gap-2 text-sm"><input type="checkbox" checked={attested} onChange={e=>setAttested(e.target.checked)} />Confirmo verificación humana FICTICIA con la fuente. Esto no comprueba hechos reales.</label><p className="mt-2 text-sm font-semibold">Para avanzar: escribe una fuente ficticia sin teléfonos ni datos personales, identifica a quien registra, selecciona el tipo del paso actual y confirma la revisión. {currentStep>=1&&!routeVerified ? 'Falta también confirmar institución, capacidad, documentos y costo en Ruta local verificada, abajo.' : ''}</p><Button disabled={!canAdvance(owner,deadline,evidence) || !evidenceReady(evidence,recorder,kind,attested,currentStep) || (currentStep>=1 && (!routeVerified || !routeFresh(routeAt)))} variant="outline" className="mt-3 w-full" onClick={() => {if(!evidenceReady(evidence,recorder,kind,attested,currentStep)||!canAdvance(owner,deadline,evidence)||(currentStep>=1&&(!routeVerified||!routeFresh(routeAt)))){recordEvent('blocked',currentStep);return;}setCorrectionNotice(false);setHistory([...history, provenance(evidence,recorder,kind)]);setCurrentStep(currentStep+1);setEvidence("");setAttested(false);setKind(["contact","acceptance","appointment","attendance"][Math.min(currentStep+1,3)]);recordEvent("advance",currentStep+1);}}>Registrar evidencia y avanzar un paso</Button></div>}
              <ol className="mt-4 text-sm">{history.map((h,i)=><li key={i}>{steps[i]}: {h.replace(/\[DEMO\|([^|]+)\|([^\]]+)\]/,(_all:string,_kind:string,at:string)=>'Verificación ficticia '+new Date(at).toLocaleString('es-MX',{timeZone:'America/Mexico_City'}))} <button className="underline" onClick={()=>{setCurrentStep(i);setHistory(history.slice(0,i));setClosed(false);setAttendanceEvidence(false);setAttested(false);setKind(["contact","acceptance","appointment","attendance"][i]);setCorrectionNotice(true);recordEvent("correct",i);}}>Corregir desde este paso</button></li>)}</ol>
              {currentStep>0 && <Button className="mt-3" variant="outline" onClick={()=>{recordEvent("correct",currentStep-1);setAttested(false);setKind(["contact","acceptance","appointment","attendance"][currentStep-1]);setCorrectionNotice(true);setCurrentStep(currentStep-1);setHistory(history.slice(0,-1));setClosed(false);setAttendanceEvidence(false);}}>Corregir último paso y reabrir</Button>}
              <p className="mt-3 text-sm text-[#657689]">La falta de respuesta se registra como <strong>No fue posible contactar</strong>, nunca como incumplimiento.</p>
              <div className="mt-6 border-t border-[#e0e9ea] pt-5"><h3 className="font-bold">Ruta local verificada</h3><p className="mt-1 text-sm text-[#657689]">Los datos simulados deben ser confirmados por una persona identificada durante las últimas 72 horas.</p><p className="mt-3 rounded-xl bg-[#f5f8f8] p-3 text-sm">Institución, disponibilidad, documentos y costo: <strong>{routeVerified ? "Confirmación simulada registrada por la navegadora" : "Unknown / pendientes de verificación"}</strong></p><label htmlFor="route-evidence" className="mt-3 block text-sm">Fuente ficticia para institución, capacidad, documentos y costo; verificada en las últimas 72 horas</label><input id="route-evidence" className="data-input mt-2 w-full" maxLength={300} value={routeEvidence} onChange={e=>{setRouteEvidence(e.target.value);setRouteAt("");setRouteVerified(false);setClosed(false);if(currentStep>=2){setCurrentStep(1);setHistory(history.slice(0,1));setAttendanceEvidence(false);setCorrectionNotice(true);setKind("acceptance");setAttested(false);recordEvent("correct",1);}}} /><label className="mt-3 flex items-center gap-2 text-sm font-medium"><Checkbox disabled={!validText(routeEvidence)} checked={routeVerified} onCheckedChange={(v) => {setRouteVerified(v===true);setRouteAt(v===true?new Date().toISOString():"");setClosed(false);if(v!==true&&currentStep>=2){setCurrentStep(1);setHistory(history.slice(0,1));setAttendanceEvidence(false);setCorrectionNotice(true);setKind("acceptance");setAttested(false);recordEvent("correct",1);}}} /> Confirmo revisión ficticia de los cuatro datos hace menos de 72 horas</label>{!routeVerified && <p className="mt-3 rounded-xl bg-[#eef1f5] p-3 text-sm font-bold text-[#445268]">No hay ruta verificada - el caso sigue abierto</p>}</div>
              <div className="mt-6 border-t border-[#e0e9ea] pt-5"><h3 className="font-bold">Cierre protegido</h3><label className="mt-3 flex items-center gap-2 text-sm font-medium"><Checkbox disabled={currentStep < 4 || closed} checked={attendanceEvidence} onCheckedChange={(v) => setAttendanceEvidence(v === true)} /> Evidencia de asistencia verificada</label><Button disabled={!canClose || !routeVerified || closed} onClick={() => {if(!routeFresh(routeAt)){setRouteVerified(false);setClosed(false);return;}setClosed(true);recordEvent("close",4);}} className="mt-4 w-full bg-[#12233f] hover:bg-[#1d3559]">{closed ? "Referencia cerrada con evidencia" : "Cerrar referencia"}</Button>{closed && <p role="status" className="mt-3 rounded-xl bg-[#e8f6ef] p-3 text-sm font-bold text-[#17603d]">Cierre académico ficticio registrado por {recorder} - evidencia: {history[3]}.</p>}<p className="mt-3 text-xs leading-5 text-[#66778a]">Un mensaje, una reservación o una cita confirmada nunca cierran el caso.</p></div>
            </>}
          </article></aside>
        </section><EventLog />
      </div>
    </main>
  );
}

