# Week 14 mechanical and persona test record
15 November 2026, America/Chicago. Fictional test data only.

## Executed mechanical checks
- Node regression suite: 14/14 pass (6 pricing + 8 inherited referral checks).
- Base: cost 2300, contribution 1200, margin 34.285714%, headroom 150 at 30% target.
- Acquisition 300: cost 2600, contribution 900, margin 25.714286%, headroom -150, target price 3714.285714.
- Zero/blank/negative/infinite/NaN/out-of-range price rejected; target 100% and hours >10 rejected.
- Stored data corruption rejected and maximum 12 valid records enforced by shared-rule tests.
- Browser local preview: saved base and acquisition scenarios, reloaded, loaded scenario 2; both rows survived. Set price 0: explicit error and save disabled. Export control produced a download event; downloaded content was not independently parsed.
- Browser production: https://ruta-clara-pied.vercel.app/pricing loaded without sign-in in this browser; saved two scenarios, reloaded, loaded scenario 2, visually confirmed 2600 cost, 25.7% margin, -150 headroom and comparison table. Production screenshot preserved.
- Next.js production build/type check passed with / and /pricing.
- Responsive CSS exists; separate narrow viewport/device test was not performed.
- Deletion and unavailable-storage handling are implemented but not manually exercised. Cross-account Supabase isolation and Google login are not newly verified.

## Real failures and fixes
1. Tax regression failed: binary floating-point returned 4059.9999999999995 rather than 4060. Fix: round displayed/exported tax-inclusive total to cents. Test now passes.
2. First deployment dpl_HXazQTZNHQcor3Zy2oR8Akruzehs failed TypeScript indexing. Fix: explicitly cast numeric-limit lookup and validation result. Local production type check passed; subsequent deployment READY.
3. Preview startup failed because generic --host/--strictPort flags do not match Next.js. Added small dev wrapper translating --host to --hostname and removing --strictPort; preview started successfully.
4. Fresh-context synthetic screenshot review identified unclear supplier/buyer perspective. Fixed by labeling whose costs/margin are modeled, defining acquisition and navigator, clarifying report deliverables and removing Supabase jargon. Reviewer inspected corrected screenshot; concern resolved at a screenshot-comprehension level.

## Deployment sequence
- dpl_HXazQTZNHQcor3Zy2oR8Akruzehs: ERROR, type-check failure (not counted as successful ship).
- dpl_GPwnh2grAMsDTPuMrrqasCxxfuJd: READY, first working pricing deployment.
- dpl_7tRPekecCyrMYdfG5HhpDz2z28TU: READY, persona wording correction deployed.
Production alias: https://ruta-clara-pied.vercel.app/pricing . Existing Vercel project prj_JiFK0jXldpWsKNHa2kcATuaAyAet was reused. No purchase or paid plan was initiated.

## Security evidence and limits
No new secret/key was added. Pricing stores only allowlisted numeric values and generated anonymous IDs in localStorage. No free-text or personal-data fields in pricing. Pricing cannot modify clinical state. Existing Supabase module remains unchanged; auth/Google and RLS are inherited limits, not newly certified. All displayed care scenarios remain fictional and AI extraction simulated. Price inputs do not trigger payment.

## Source publication
Six meaningful Week 14 local commits existed before final evidence commit. Git push failed: no executor GitHub credentials. GitHub create_tree returned 403 Resource not accessible by integration. Browser showed public repo logged out. Remote main remains at 3fda80628f823036f39f4e391b727c1fd34bf943; do not claim Week 14 is uploaded. Source ZIP and git bundle preserve actual local work/history for upload.
