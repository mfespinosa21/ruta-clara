# Demo guide / 3 minutes + 30 seconds
Record yourself using the LIVE page: https://ruta-clara-pied.vercel.app/pricing . File: DEMO_FernandaEspinosa.mp4. These are speaking cues; describe only what you actually show. Do not claim real buyers or clinical deployment.

## 0:00-0:35 / User, payer and offer
"This is Ruta Clara's Week 14 pricing slice. The organization pays for a four-week evaluation using ten fictional referral scenarios. The proposed price is 3,500 Mexican pesos before any applicable tax. Patients pay nothing. This is an evaluation of the workflow, not a live clinical service. It includes one organization, one site, one navigator, onboarding, bounded support and a final report, with a ten-hour delivery limit."
Show offer and fictional-data notice.

## 0:35-1:15 / Count all costs
"The calculator shows Ruta Clara's supplier economics. Ten hours at 200 pesos plus 300 in tools produces a cost of 2,300. At a 3,500 price, contribution is 1,200, or 34.3 percent. The target is 30 percent, so only 150 pesos remains for additional costs. Founder time is included. This is contribution margin, not company net profit."
Save the base scenario. Explain costs are hypotheses.

## 1:15-1:55 / Change and save
"Now I add 300 pesos to acquire the buyer. Total cost becomes 2,600, and margin falls to 25.7 percent. The target fails. To reach a 30 percent margin at this cost, the pretax price would need to be about 3,714.29 pesos. I can change scope or price, but I should not hide labor costs."
Save scenario 2. Scroll to comparison; reload and load scenario 2.

## 1:55-2:25 / Value and shadow
"Saving assumptions is not payment evidence. A 10-to-1 benefit ratio at 3,500 requires 35,000 pesos of verified benefit for the organization over the same four weeks. I have not demonstrated that. The calculator labels benefit as a hypothesis. Payment never changes evidence requirements or closes an unresolved referral."
Show value section, shadow clause and export.

## 2:25-3:00 / Test, fix and limits
"Fourteen regression checks passed, and two corrected deployments reached READY. The mechanical test found a monetary precision error, which was fixed. A fresh synthetic persona review found that whose costs were being modeled was unclear. The corrected screen explicitly says these are supplier costs. This was a synthetic screenshot review, not an interview. Scenarios are stored only in this browser. The free Vercel URL works, but the required owned domain and GitHub source upload remain pending."
Show corrected perspective and live table. Do not imply all security floor requirements are certified.

## 3:00-3:30 / What changed my mind
"I started with 3,500 pesos as a convenient price to test. What changed my mind was how quickly the margin disappears once I count acquisition. The base case leaves just 150 pesos before missing the target, so a positive contribution alone does not prove sustainable delivery. I now need two separate kinds of evidence: that an authorized buyer actually pays, and that I can deliver the defined scope with the full costs included. A higher price would not prove value either. The next test is the same written offer to five eligible organizations, without inventing payments, savings or renewals."
