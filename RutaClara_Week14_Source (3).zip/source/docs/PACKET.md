# Ruta Clara / Week 14 / Pricing
María Fernanda Espinosa | 232277-2 | 15 November 2026

## Problem and exact user
A budget owner at a Mexican clinic or funded patient-navigation organization needs to decide whether a bounded fictional workflow evaluation is affordable and sustainable. A navigator benefits; an authorized organizational budget owner pays; the patient pays nothing. This slice makes price, founder labor, acquisition and uncertainty visible before any purchase. All numbers are hypotheses, not observed buyer outcomes.

## Success before the module closes
The existing Next.js referral prototype remains available. At /pricing, a user edits cost assumptions, sees contribution margin, price required for a target margin, benefit-to-price ratio and a tax estimate, then saves, reloads, compares and deletes fictional scenarios. Saved scenarios survive page reload in this browser. No clinical or identifying data enters pricing storage.

## Offer
MXN 3,500 before any applicable tax for four weeks, one organization/site, one navigator, ten fictional referral scenarios, one onboarding session, bounded support, final workflow/cost report; maximum ten delivery hours. No real patient operations, integrations or automatic renewal. Confirm tax treatment and disclose total before actual payment. Extra work is separately quoted.

## Image-generated mockup
Concept image generated during this session; concept, not evidence that the application worked. File: week14/mockup-week14.png when generation completes. The image-generation request precedes calculator implementation.

## Flow
```mermaid
flowchart TD
 A[Open fictional evaluation] --> B[Enter price and full cost assumptions]
 B --> C{Inputs valid?}
 C -->|No| D[Explain field error]
 D --> B
 C -->|Yes| E[Calculate margin and benefit ratio]
 E --> F[Save scenario in this browser]
 F --> G[Reload and compare]
 G --> H[Export financial assumptions]
```

## Responsibility swimlanes
```mermaid
flowchart TD
 subgraph Buyer
 A[Review bounded offer]
 B[Change assumptions]
 C[Compare saved scenarios]
 end
 subgraph Calculator
 D[Validate finite numbers and limits]
 E[Calculate transparent formulas]
 F[Save financial assumptions locally]
 end
 subgraph Human_operator
 G[Confirm actual scope and tax treatment]
 H[Verify evidence independently of payment]
 end
 A --> B --> D --> E --> F --> C
 C --> G --> H
```

## Benchmark: global to local
My chosen global benchmark is Unite Us, whose closed-loop referral platform follows referrals and outcomes across a partner network; this is a benchmark choice, not an independently proven world ranking. Ruta Clara localizes a bounded Spanish-language fictional evaluation and explicit MXN economics without claiming an equivalent network or clinical capability.
Findhelp separates organizational subscriptions from resource access; its prices are not evidence of Mexican willingness to pay. Sources checked this session: https://uniteus.com/products/closed-loop-referral-system/ and https://company.findhelp.com/pricing/ .

## Three-year view
If the evaluation works, Ruta Clara could become a locally governed referral coordination service with participating receiving organizations and accountable human verifiers. Sustainable institutional contracts would fund navigation without charging patients for favorable verification. Real clinical deployment would require separate privacy, security, legal and operational validation, not an extrapolation from fictional tests.

## Scope cut
No checkout, real buyer outreach, clinical advice, live booking, payment collection or real patient data. No invented purchases, savings, renewal or user research. No AI forecasting: deterministic formulas only. Pricing scenarios are browser-local, not shared or cloud-synced. The missing Crystal Ball Brief and chapter-specific shadow requirements remain unverified.

## Architecture and stack
| Layer | Implementation |
|---|---|
| UI | Existing Next.js / React / Tailwind; scoped pricing CSS |
| Rules | Pure JavaScript pricing module, imported by UI and Node tests |
| Pricing persistence | Validated localStorage, financial numbers only; maximum 12 scenarios |
| Existing backend | Inherited optional Supabase fictional-session module; unchanged |
| Hosting/source | Existing Vercel project / GitHub mfespinosa21/ruta-clara |
| AI | No AI in pricing; inherited extraction remains labeled simulated |

## Formulas and assumptions
Cost = delivery hours × fully loaded hourly rate + tools + acquisition + contingency.
Contribution = pretax price - cost. Margin = contribution / pretax price. Target price = cost / (1 - target margin).
Benefit ratio = assumed same-period buyer benefit / pretax price; not ROI and not verified savings. 10:1 at 3500 requires 35000; at 200/hour that is 175 hours of benefit. Tax is a user-set illustrative rate, not revenue or legal tax advice. Margin excludes taxes collected and is not company net profit.

## Shadow clause and security floor
Payment must never change referral status or evidence requirements. Pricing UI has no write path to clinical evidence. No fees for positive outcomes or paid verification priority. Existing unresolved states remain unresolved. No secrets are added. Numeric inputs use limits/type checks; scenarios use fixed anonymous codes, not names. No new personal data table; auth/RLS remain inherited and are not newly certified. Existing Google Sign-In gap must be disclosed if assessed across the whole app.

## Test plan
Check base cost 2300, contribution 1200, margin 34.2857%, target cost ceiling 2450 and headroom 150. Check acquisition 300 causes target failure (2600 cost, 25.7143% margin). Reject blank, negative, NaN, infinite and out-of-range inputs; reject price 0 and margin 100%. Test round-trip, malformed saved data, browser-storage failure, maximum records, load/delete/export and mobile layout. Run inherited Week 13 regressions. Record actual failure/fix/retest; do not manufacture a bug. Fresh synthetic persona screenshot review is a separate test, not a real user session.

## Delivery limits
Real owned domain is not connected. Free Vercel URL does not fulfill the explicit real-domain rule without instructor exception. Student demo video and full verbatim chat export require the student. Generated development log must identify itself as a record, not a fabricated full transcript.
